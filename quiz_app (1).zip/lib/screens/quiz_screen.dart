import 'package:flutter/material.dart';
import 'package:quiz_app/models/question.dart';
import 'package:quiz_app/services/quiz_service.dart';
import 'package:quiz_app/screens/result_screen.dart';
import 'dart:async';

class QuizScreen extends StatefulWidget {
  @override
  _QuizScreenState createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  late Future<List<Question>>? questions;
  int currentIndex = 0;
  int score = 0;
  bool answered = false;
  int secondsRemaining = 300; // 5 minutes

  late Timer timer;

  @override
  void initState() {
    super.initState();
    // Load questions when the widget initializes
    questions = QuizService().getQuestions();

    timer = Timer.periodic(Duration(seconds: 1), (Timer t) {
      setState(() {
        if (secondsRemaining > 0) {
          secondsRemaining--;
        } else {
          timer.cancel();
          // Quiz timer expired, navigate to result screen
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => ResultScreen(
                score: score,
                totalQuestions: currentIndex + 1,
              ),
            ),
          );
        }
      });
    });
  }

  void checkAnswer(int selectedIndex) {
    if (questions != null && !answered) {
      questions!.then((value) {
        bool isCorrect = (selectedIndex == value[currentIndex].correctIndex);
        setState(() {
          answered = true;
          if (isCorrect) {
            score++;
          }
        });

        // Afficher le feedback pendant quelques secondes
        Future.delayed(Duration(seconds: 2), () {
          nextQuestion();
        });
      }).catchError((error) {
        print(error);
      });
    }
  }

  void nextQuestion() {
    if (questions != null) {
      questions!.then((value) {
        if (currentIndex < value.length - 1) {
          setState(() {
            currentIndex++;
            answered = false; // Réinitialiser le statut de la réponse
          });
        } else {
          timer.cancel();
          // Quiz ended, navigate to result screen
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => ResultScreen(
                score: score,
                totalQuestions: value.length,
              ),
            ),
          );
        }
      }).catchError((error) {
        print(error);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Questions',
          style: TextStyle(
            fontSize: 24, // Taille de police plus grande
            fontWeight: FontWeight.bold, // Texte en gras
            color: Color(0xff5a67e3), // Couleur de texte violette
          ),
        ),
      ),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.timer),
                SizedBox(width: 5),
                Text(
                  '${secondsRemaining ~/ 60}:${(secondsRemaining % 60).toString().padLeft(2, '0')}',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
              ],
            ),
            SizedBox(height: 20.0),
            FutureBuilder<List<Question>>(
              future: questions,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError) {
                  return Center(child: Text('Error: ${snapshot.error}'));
                } else if (snapshot.hasData) {
                  List<Question> data = snapshot.data!;
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text('Question ${currentIndex + 1}/${data.length}'),
                      SizedBox(height: 10.0),
                      Text(data[currentIndex].question,
                          style: TextStyle(fontSize: 20.0)),
                      SizedBox(height: 20.0),
                      ...data[currentIndex]
                          .options
                          .asMap()
                          .entries
                          .map((entry) {
                        int index = entry.key;
                        String option = entry.value;
                        return Padding(
                          padding: EdgeInsets.symmetric(vertical: 10.0),
                          child: ElevatedButton(
                            onPressed: () {
                              checkAnswer(index);
                            },
                            style: ElevatedButton.styleFrom(
                              primary: answered
                                  ? (index == data[currentIndex].correctIndex
                                      ? Colors.green
                                      : Colors.red)
                                  : Colors.blue,
                              onPrimary: Colors.white,
                            ),
                            child: Text(option),
                          ),
                        );
                      }).toList(),
                    ],
                  );
                } else {
                  return Center(child: Text('No data'));
                }
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    timer.cancel();
    super.dispose();
  }
}
