import 'package:flutter/material.dart';

import 'start.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Quiz JavaScript',
          style: TextStyle(
            fontSize: 24, // Taille de police plus grande
            fontWeight: FontWeight.bold, // Texte en gras
            color: Color(0xfff7f4f8), // Couleur de texte violette
          ),
        ),
        centerTitle: true,
        backgroundColor: Color(0xff379ecd),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.info),
            onPressed: () {
              // Action à effectuer lors du clic sur le bouton d'information
              // Par exemple, naviguer vers une nouvelle page d'informations
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => MoreInfoPage()),
              );
            },
          ),
          // Vous pouvez ajouter d'autres IconButton ici pour plus d'actions
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(
                'assets/quiz.png'), // Assurez-vous que le chemin est correct ici
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => StartScreen()),
              );
            },
            style: ElevatedButton.styleFrom(
              primary: Color(0xffb470bf), // Couleur de fond du bouton
              onPrimary: Colors.white, // Couleur du texte du bouton
              padding: EdgeInsets.symmetric(horizontal: 40, vertical: 20),
            ),
            child: Text(
              'START',
              style: TextStyle(fontSize: 23),
            ),
          ),
        ),
      ),
    );
  }
}

class MoreInfoPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Lien utiles',
          style: TextStyle(
            fontSize: 24, // Taille de police plus grande
            fontWeight: FontWeight.bold, // Texte en gras
            color: Color(0xff5553d7), // Couleur de texte violette
          ),
        ),
      ),
      body: Center(
        child: Text(
            'pour mieux apprendre javascript vous pouvez visiter :                                                 HTML: https://www.w3schools.com/html/,W3Schools CSS: https://www.w3schools.com/css/,W3Schools JavaScript: https://www.w3schools.com/js/'),
      ),
    );
  }
}
