import 'package:flutter/material.dart';

class ResultScreen extends StatelessWidget {
  final int? score;
  final int? totalQuestions;

  ResultScreen({Key? key, this.score, this.totalQuestions}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Calcul du pourcentage
    double percentage =
        score != null && totalQuestions != null && totalQuestions! > 0
            ? (score! / totalQuestions!) * 100
            : 0.0;

    // Déterminer le message basé sur le pourcentage
    String message;
    if (percentage >= 80) {
      message =
          'Félicitations ! Vous avez réussi le quiz avec un excellent score de $score/$totalQuestions!';
    } else if (percentage >= 50) {
      message =
          'Bravo ! Vous avez réussi le quiz avec un score de $score/$totalQuestions.';
    } else {
      message =
          'Dommage, votre score est de $score/$totalQuestions. Continuez à vous entraîner !';
    }

    return Scaffold(
      appBar: AppBar(title: Text('Résultat')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Résultat du Quiz',
              style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.blue),
            ),
            SizedBox(height: 20),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18, color: Colors.black),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context); // Retour à l'écran précédent
              },
              style: ElevatedButton.styleFrom(
                primary: Colors.blue, // Couleur de fond du bouton
                onPrimary: Colors.white, // Couleur du texte du bouton
                padding: EdgeInsets.symmetric(horizontal: 40, vertical: 20),
              ),
              child: Text(
                'Rejouer',
                style: TextStyle(fontSize: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
