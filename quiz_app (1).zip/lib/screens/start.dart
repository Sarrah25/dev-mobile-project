import 'package:flutter/material.dart';
import 'quiz_screen.dart';

class StartScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Acceuil',
          style: TextStyle(
            fontSize: 24, // Taille de police plus grande
            fontWeight: FontWeight.bold, // Texte en gras
            color: Color(0xff4681cd), // Couleur de texte violette
          ),
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Vous aurez 5 minutes pour répondre à des questions de JavaScript. Lisez-les attentivement puis choisissez la bonne réponse.',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.blue,
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => QuizScreen()),
                );
              },
              child: Icon(
                Icons.arrow_forward,
                size: 50,
                color: Colors.white,
              ),
              style: ElevatedButton.styleFrom(
                shape: CircleBorder(),
                padding: EdgeInsets.all(20),
                primary: Colors.blue,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
